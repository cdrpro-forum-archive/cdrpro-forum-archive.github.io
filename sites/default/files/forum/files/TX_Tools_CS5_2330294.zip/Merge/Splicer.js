/* ==================================
Splicer (NL)
Version 0.2
(c) vd [vd(kot)online.com.ua]
Edit by Sancho (c) 2010, http://cdrpro.ru/forum/55

This software is distributed under the  
terms of GNU General Public License.
http://www.gnu.org/licenses/gpl.html
================================== */


function topOrder(a,b) {
	if (a.top == b.top) {
		return a.left - b.left;
	} else {
		return b.top - a.top;
	}
}

if(documents.length > 0) {
	var doc = activeDocument;
	var mySelection = activeDocument.selection;

	if (mySelection instanceof Array) {
		mySelection.sort(topOrder);
		var newFrame = mySelection[0].parent.textFrames.add();
		newFrame.top = mySelection[0].top;
		newFrame.left = mySelection[0].left;

		while( mySelection.length )
		if ( mySelection[0].typename == "TextFrame" ) {
			myFrame = mySelection.shift();
			if(mySelection.length>0) myFrame.paragraphs.add("");
			myFrame.textRange.duplicate(newFrame);
			myFrame.remove();
		}
		else {
			mySelection.shift();
		}
	}
}