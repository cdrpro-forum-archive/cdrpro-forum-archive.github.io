/* ==================================
Para Breaker
Version 0.2
(c) vd [vd(kot)online.com.ua]
Edit by Sancho (c) 2010, http://cdrpro.ru/forum/55

This software is distributed under the  
terms of GNU General Public License.
http://www.gnu.org/licenses/gpl.html
================================== */


if(documents.length > 0) {
	var doc = activeDocument;
	var mySelection = activeDocument.selection;
	if (mySelection instanceof Array)
	for(i=0; i<mySelection.length; i++)
	if (mySelection[i].typename == "TextFrame") {
		var obj = mySelection[i];
		var objTop = obj.top;
		var objLeft = obj.left;

		for(i=0; i<obj.paragraphs.length; i++) {
			var textRef = obj.parent.textFrames.add();
			try {obj.paragraphs[i].duplicate(textRef)} catch(e) {}
			textRef.left = objLeft;
			textRef.top = objTop;
			objTop -= textRef.height;
		}
		obj.remove();
	}
}