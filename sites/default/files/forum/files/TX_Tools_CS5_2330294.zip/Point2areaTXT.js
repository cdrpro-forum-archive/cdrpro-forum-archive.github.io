/* ==================================
Framer
Version 0.2
(c) vd [vd(kot)online.com.ua]
Edit by Sancho (c) 2010, http://cdrpro.ru/forum/55

This software is distributed under the  
terms of GNU General Public License.
http://www.gnu.org/licenses/gpl.html
================================== */


if(documents.length > 0) {
	var doc = activeDocument;
	var mySelection = activeDocument.selection;
	if (mySelection instanceof Array) {
		WH = prompt("Enter width and height (in mm) of text frame:", "50,50");
		if (WH){
			WHS = WH.split(',',2);
			var fHeight = WHS[1]*72/25.4;
			var fWidth  = WHS[0]*72/25.4;

			for (i=0; i<mySelection.length; i++)
			if (mySelection[i].typename == "TextFrame" && mySelection[i].kind == TextType.POINTTEXT) {
				var obj = mySelection[i];	
				var myRect = doc.pathItems.rectangle(obj.top, obj.left, fWidth, fHeight);
				var textRef = doc.textFrames.areaText(myRect);
				textRef.selected = true;

				obj.textRange.duplicate(textRef);
				obj.remove();
			}
		}
	}
}